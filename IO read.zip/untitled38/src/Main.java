import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.*;

public class Main {

    public static void main(String[] args) throws IOException {
        File fe = new File("C:\\Programavimas\\JAVA\\untitled38\\failas.txt");
        FileInputStream is = new FileInputStream(fe);

        int b;
        String tekstas = "";
        while ((b = is.read()) != -1) {

            tekstas = tekstas + (char) b;


        }
        is.close();

         tekstas = tekstas.replaceAll("\r?\n", "");
        //System.out.println(tekstas3);

        String[] textArray = tekstas.split(" ", 999999999);
         ArrayList<String> textArray2 = new ArrayList();

        for (int i = 0; i < textArray.length; i++) {

            if (textArray[i].length() > 0) {
                Boolean tempB = true;
                while (tempB) {

                    char x = textArray[i].charAt(textArray[i].length() - 1);
                    String y="";
                    if (x == '.' || x == '?' || x == '!' || x == ',') {
                        textArray[i] = textArray[i].replace(textArray[i].substring(textArray[i].length() - 1), "");
                    } else {
                        tempB = false;}
                        textArray2.add(textArray[i]);

                }
            }
        }
       // for (Object a : textArray2)
       //     System.out.println(a);
        String temp= "";
        for (int i = 0; i< textArray2.size();i++){
            for (int j = 0; j< textArray2.size()-1;j++){
                if (textArray2.get(j).length()<textArray2.get(j+1).length()){
                    temp = textArray2.get(j);
                    textArray2.set(j,textArray2.get(j+1));
                    textArray2.set(j+1,temp);
                }
            }
        }
        for (Object a : textArray2)
            System.out.println(a);
        System.out.println("pabaiga");
    }
    public static final String NEW_LINE = System.getProperty("line.separator");
}

